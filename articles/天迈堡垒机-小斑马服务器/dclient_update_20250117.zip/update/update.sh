#!/bin/sh

LOG_FILE="/mnt/nand/shell_update.log"
DOWNLOAD_PATH="/mnt/downloads/update/"

rm $LOG_FILE

LOG() {
    echo "[$(date)] $1" >> $LOG_FILE
    #echo "[$(date)] $1"
}

if [ ! -d $DOWNLOAD_PATH ]; then
    DOWNLOAD_PATH="/mnt/emmc_log/update/" 
fi

if [ ! -f $DOWNLOAD_PATH"update.sh" ]; then
    LOG "${DOWNLOAD_PATH}update.sh isn't exist."
    exit 1
fi

LOG "DOWNLOAD_PATH [$DOWNLOAD_PATH]"

MACHINE=""
if [ -f "/mnt/flash/businfo.cfg" ];then 
    MACHINE=$(cat /mnt/flash/businfo.cfg |grep "paraMachineNum" |awk -F "=" '{print $2}')
elif [ -f "/mnt/memory/sch/SchBusInfo.ini" ];then
    MACHINE=$(cat /mnt/memory/sch/SchBusInfo.ini |grep "machNo"|awk '{print $3}')
else
    LOG "/mnt/flash/businfo.cfg isn't exist."
fi

MACHINE=$(echo "$MACHINE" | tr -d ';') 

LOG "MACHINE: $MACHINE"

if [ ${#MACHINE} -gt 6 ]; then
    case $((MACHINE % 5)) in
        0)
            cp -f $DOWNLOAD_PATH"dclient_para_14317.json" "/mnt/flash/dclient_para.json"
            LOG "cp -f ${DOWNLOAD_PATH}dclient_para_14317.json /mnt/flash/dclient_para.json"
            ;;
        1)
            cp -f $DOWNLOAD_PATH"dclient_para_14318.json" "/mnt/flash/dclient_para.json"
            LOG "cp -f ${DOWNLOAD_PATH}dclient_para_14318.json /mnt/flash/dclient_para.json"
            ;;
        2)
            cp -f $DOWNLOAD_PATH"dclient_para_14319.json" "/mnt/flash/dclient_para.json"
            LOG "cp -f ${DOWNLOAD_PATH}dclient_para_14319.json /mnt/flash/dclient_para.json"
            ;;
        3)
            cp -f $DOWNLOAD_PATH"dclient_para_14320.json" "/mnt/flash/dclient_para.json"
            LOG "cp -f ${DOWNLOAD_PATH}dclient_para_14320.json /mnt/flash/dclient_para.json"
            ;;
        4)
            cp -f $DOWNLOAD_PATH"dclient_para_14321.json" "/mnt/flash/dclient_para.json"
            LOG "cp -f ${DOWNLOAD_PATH}dclient_para_14321.json /mnt/flash/dclient_para.json"
            ;;
    esac
    
else
    #无法识别到正常的机器号,默认使用14316
    cp -f $DOWNLOAD_PATH"dclient_para_14316.json" "/mnt/flash/dclient_para.json"
    LOG "unknow machine, will [cp -f ${DOWNLOAD_PATH}dclient_para_14316.json /mnt/flash/dclient_para.json]"
fi

sync

killall -9 dclient
